<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="post" action=>
<center>
ROOM Type<input type="text" id="ROOM_TYPE" name="rtype" value="<?php echo $_GET['rtype'];?>"readonly><br><br>

AVAILAABLE ROOM<input type="text" id="available" name="avl"value="<?php echo $_GET['avl'];?>" readonly><br></br>
ROOM NEEDED <input type="number" id="ROOM_NEEDED" name="rneed"><br><br>
<br>
<input type="submit" value="COINFOIRM_BOOKING" name="booked">
</center>
</form>
</body>
</html>
<?php
//error_reporting(0);
include "connection.php";
$ids=$_GET['id'];
$_GET['rtype'];
$_GET['avl'];
if(isset($_POST['booked']))
{
$roomtype=$_REQUEST['rtype'];
$avlroom=$_REQUEST['avl'];
$room_needed=$_REQUEST['rneed'];

//"UPDATE available_item SET available_quantity=(available_quantity -'$Quantity'),order_quantity='$Quantity'WHERE item_no='$ids'";
$sql="UPDATE `booking_details` SET`available`=(available-$room_needed),room_needed=$room_needed WHERE id='$ids'";
$data=mysqli_query($conn,$sql);
if($data)
{
    
echo'<script> alert("room booking complete")</script>';
echo'<script>window.location.href="/hotel/roomfetch.php"</script>';

}
}
?>