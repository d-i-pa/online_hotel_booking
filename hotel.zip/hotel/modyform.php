<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
<style>
*{
    margin: 0;
    padding: 0;
}
body{
    background-image: url(hotelpic/room.jpg);
    background-position: center;
    background-size: auto;
    /*background-color:black ;*/
}
#form{
    background-color: #000;
    height:497px;
    width:800px;
    margin: auto;
    margin-top: 100px;
    opacity:0.7;
}
#first-group{
    border:none;
    width:400px;
    margin-top: 38px;
    position: absolute;
}
#content{
    border: 1px solid #fff;
    margin:10px;
    margin-left: 8px;
    padding:5px;
}
#content #input-group{
    border:none;
    outline:none;
    background: transparent;
    margin-left:8px;
    width:300px;
    color:#fff;
}
::placeholder{
    color:#fff;
}
.fa{
    display:inline-block;
    color:red;
    border-right:1px solid #fff;
    padding:8px;
    margin-left: 8px;
}
#second-group{
    border:none;
    width:400px;
    margin-top: 55px;
    margin-left:400px;
}
#submit-btn{
    margin-top: 30px;
    margin-left: 600px;
    background: transparent;
    color:#fff;
    width:150px;
    border:1px solid red;
    outline:none;
    padding:10px;
    font-size: 20px;
} 
#content1{
 
    border: 1px solid #fff;
    margin: 10px;
    margin-left: 8px;
    padding: 5px;
    height: 44px;
}
.radio{
            transform: translate(49px, 1px);
}
.radio1{
            transform: translate(31px, 1px);
}
#content2{
  border: 1px solid #fff;
    margin: 10px;
    margin-left: 8px;
    padding: 5px;
    height: 40px;
}
.bttn{
        transform: translate(-391px, -20px);
}
nav
{
    background-image: linear-gradient(to right,#f59295,#fce18a);
}
#col{
     background-color: #000;
    height:410px;
    width:800px;
    margin: auto;
    margin-top: 100px;
    opacity:0.7;
}
</style>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Moody Moon</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
       
        <a class="nav-link" href="/hotel/reserve.php">Booked Room<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/hotel/totalroom.php">Total Room</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"></a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#" tabindex="-1" aria-disabled="true"></a>
      </li>
    </ul>
  </div>
</nav>
</head>
<body>
  <div id="col">
    <marquee width="750px" direction="up" height="400px">
    <h1 style="color:#FF0000;"><center>Contact Dealish of MOODY MOON<center></h1>
    <h4 style="color:#ff5c31;"><p style="color:#ff5c31;"><center><b>Contact Detlis of MOODY MOON 7003686883/7890669381(Number Will be active from 10am to 11.30 pm)</b><center></p></h4>
    <h5 style="color:#ff5c31;"><p><b>Email_id are</b><a href="#" style="color:#ff5c31;">moodymoon2000@gmail.com/ &nbsp &nbsp moodymoonbook1278@gmail.com</a></p><h5>
    </marquee>
        <div>
    
    <form method="post" class="form-group">
      <div id="form">
        <h1 class="text-white text-center">Booking Now</h1>
          <div id="first-group">

              <div id="content">
                <i class="fa fa-user" aria-hidden="true"></i>
                    <input type="text" id="input-group" placeholder="Enter  First Name" name="fname" id="fname"  required>
                </div>
    <!--<input type="text" placeholder="Enter  Last Name" name="lname" id="lname"  required>-->

                 <div id="content">
                    <i class="fa fa-envelope-o" aria-hidden="true"></i>
                        <input type="email" id="input-group"  name="email"  placeholder="Email">
                    </div>

    <div id="content1">
        <i class="fa fa-car" aria-hidden="true"></i>
        <label for="free pickup" id="input-group" style="color:white">FREE PICKUP</label>
        <input type="radio" id="input-group" class="radio1" name="pickme" value="Yes!Pick Me Up On Arrival">
    </div>
    <div id="content1">
        <i class="fa fa-car" aria-hidden="true"></i>
         <label for="free pickup" id="input-group" style="color:white;">No Thanks</label>
         <input type="radio" id="input-group" class="radio" name="pickme" value="No Thanks I will arrenge"><br></br>
    </div>
   
    <div id="content">
      <i class="fa fa-fighter-jet" aria-hidden="true"></i>
        <input type="text" placeholder="Enter Your Flight Number" name="no1" id="input-group" required>
        </div>
      <div id="content">
        <i class="fa fa-train" aria-hidden="true"></i>
           <input type="text" placeholder="Enter Your Train Number" name="no2" id="input-group" required>
          </div>
</div>
  <div id="second-group">
     <div id="content">
        <i class="fa fa-user" aria-hidden="true"></i>
       <input type="text" placeholder="Enter  Last Name" name="lname" id="input-group"  required>
      </div>
     <div id="content">
      <i class="fa fa-bed" aria-hidden="true"></i>
    <select name="room" id="input-group" style="background-color: black";>
    <option value=""> Please Select room type </option>
    <option value="Standard Room (1 to 2 People)"> Standard Room (1 to 2 People) </option>
    <option value="Family Room (1 to 4 People)"> Family Room (1 to 4 People) </option>
    <option value="Privet Room(1 to 3 People)"> Privet Room(1 to 3 People) </option>
    <option value="Mix Dorm Room (6 People)"> Mix Dorm Room (6People) </option>
    <option value="Female Dorm Room (6 people)"> Female Dorm Room(6) </option>
    <option value="Male Dorm Room (6 people)"> Male Dorm Room(6) </option>
    </select><br></br>
   </div>
    <div id="content">
       <i class="fa fa-square" aria-hidden="true"></i>
        <input type="text" name="need" placeholder="enter number of room you need" id="input-group">
     </div>
    <div id="content">
       <i class="fa fa-sort-numeric-desc" aria-hidden="true"></i>
    <input type="number" placeholder="select Number of gueste" name="gust" id="input-group" required>
   </div>
    <div id="content">
       <i class="fa fa-comment" aria-hidden="true"></i>
    <textarea id="input-group"  name="spacial" row="4" cols="50" placeholder="Special request" required></textarea>
  </div>
    <div>
   <button type="submit" class="bttn" id="submit-btn" name="BOOK">Confirm</button>
   </div>
</form>
</div>
</body>
</html>
<?php
error_reporting(0);
//session_start();
  include "connection.php";
  $fnm=$_POST['fname'];
  $lnm=$_POST['lname'];
  $email=$_POST['email'];
  $pick=$_POST['pickme'];
  $flight=$_POST['no1'];
  $train=$_POST['no2'];
  $room=$_POST['room'];
  $need=$_POST['need'];
  $gust=$_POST['gust'];
  $req=$_POST['spacial'];
  if(isset($_POST['BOOK'])){
      $sql="INSERT INTO `moody_moon`(`room_number`, `fname`, `lname`, `email`, `free_pickup`, `flight_number`, `train_number`,`room_type`,`room_needed`, `no_of_guests`, `special_requests`) VALUES ('','$fnm','$lnm','$email','$pick','$flight','$train','$room','$need','$gust','$req')";
    $result=mysqli_query($conn,$sql);
    if($result)
    {
        echo'<script>alert("show and confirm your booking")</script>';
        echo"<script>window.location.href='/hotel/fetch.php'</script>";

    }
    else
    {
      echo'<script>alert("there is some problem")</script>';
      echo"<script>window.location.href='/hotel/modyform.php'</script>";
    }
    //echo"<a href='/hotel/reserve.php'>Total number of booked room</a>";
  }
?>