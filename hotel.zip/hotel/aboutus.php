<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>About Us</title>
	<link rel="stylesheet" href="/hotel/style2.css">
</head>
<body>
	<div class="container">
    <center>
      <h1>About Us..</h1>
       <div class="img">
         </div>
           <p>Having a glimpse into parties, business events and even weddings will make blog readers feel like VIPs. Perhaps a celebrity attended a press event at your hotel. If you can promote this after the fact, it may encourage new bookings. Likewise, your blog audience will no doubt include brides-to-be. If they see photos from a wedding on your hotel grounds, they could be inspired to find out more about hosting their own wedding at the property. Pictures are worth a thousand words, and a slideshow makes an easy blog post that makes readers feel special. <p>
           
           <button class="btn"><a style="color: #424949 " href="/hotel/homepage.php">Thank you</a></button>
       </center>
       </div>
   </body>
</html>