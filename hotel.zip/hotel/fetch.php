<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>show booking detalish</title>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
	width: 100%px;
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<form method="post">
<b>Enter booking Mail_id:</b><input type="text"  name="email" value="">
<button type="submit" name="search" value="Search Detalis">Search Here</button>
</form>
</body>
</html>
<?php
include"connection.php";
error_reporting(0);
$email=$_POST['email'];
if(isset($_POST['search']))
{
$sql="select * from moody_moon where email='$email'";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
	echo"<table>";
	echo"<tr>";
	echo"<th>ROOM NO.</th>";
	echo"<th>First Name.</th>";
	echo"<th>LAST NAME.</th>";
	echo"<th>EMAIL.</th>";
	echo"<th>FREE PICK UP.</th>";
	echo"<th>FLIGHT NO.</th>";
	echo"<th>TRAIN NUMBER.</th>";
	echo"<th>ROOM TYPE.</th>";
	echo"<th>ROOM NEEDED</th>";
	echo"<th>GUSTES NO.</th>";
	echo"<th colspan='2'>COMMENT.</th>";
    echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
    	echo"</tr>";
    	echo"<td>".$row['room_number']."</td>";
    	echo"<td>".$row['fname']."</td>";
    	echo"<td>".$row['lname']."</td>";
    	echo"<td>".$row['email']."</td>";
    	echo"<td>".$row['free_pickup']."</td>";
    	echo"<td>".$row['flight_number']."</td>";
    	echo"<td>".$row['train_number']."</td>";
    	echo"<td>".$row['room_type']."</td>";
    	echo"<td>".$row['room_needed']."</td>";
      echo"<td>".$row['no_of_guests']."</td>";
    	//echo"<td>".$row['room_number']."</td>";
    	echo"<td>".$row['special_requests']."</td>";
    	echo"</tr>";
    	 }

     }
echo"</table>";

       echo"<a href='/hotel/roomfetch.php'>CLICK HERE TO CONFIRM YOUR ROOM BOOKING</a>";
       

}

?>