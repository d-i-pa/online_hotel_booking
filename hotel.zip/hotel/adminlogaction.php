<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>logaction</title>
</head>
<body>

</body>
</html>
<?php
  include "connection.php";
   $user=$_REQUEST['user'];
   $pass=$_REQUEST['pass'];
   if(isset($_POST['login']))
   {
   	$sql="select * from `admintb` where username='$user'and password='$pass'";
   	$result=mysqli_query($conn,$sql);
   	if($result)
   	{
   		echo'<script>alert("log in sucessfull")</script>';
   		echo'<script>window.location.href="/hotel/admindashboard.php"</script>';
   	}
   	else
   	{
   		echo'<script>alert("there is some problem")</script>';
   		echo'<script>window.location.href="/hotel/adminlogin.php"</script>';
     }
   }
?>