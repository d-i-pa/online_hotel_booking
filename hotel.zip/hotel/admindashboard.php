<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>show hotel Deatlias</title>
</head>
<body>
	<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color:#33FFFF ;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color:#008080;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #FFEFD5;
}/*text and passord filed*/

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color:#0000CC;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
<P><center><b><h1 style="color:#FF0066 ">DRP ONLINE HOTEL LOG IN PROTAL FOR ADMIN</h1></b></center></p>
</head>
<body>
<form method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1 style="color:#FF0099">Update Hotel Property</h1>
    <p style="color:#FF0099">Only admin access</p>
    <hr>

    <label for="MOODY MOON" style="color:#FF0099"><b>MOODY MOON</b></label>
    <button type="submit" name="show" value="show">SHOW DETALISH</button>
    </div>
  </div>
</form>
</body>
</html>
?>
<?php
include"connection.php";
//error_reporting(0);
//$email=$_POST['email'];
if(isset($_POST['show']))
{
$sql="select `id`,`room_type`,`available` from booking_details";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
  echo"<table>";
  echo"<tr>";
  echo"<th>ROOM ID.</th>";
  echo"<th>ROOM TYPE.</th>";
  echo"<th>ROOM AVAILABLE</th>";
  //echo"<th>ROOM NEEDED.</th>";
  echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
      echo"</tr>";
      echo"<td>".$row['id']."</td>";
      echo"<td>".$row['room_type']."</td>";
      echo"<td>".$row['available']."</td>";
      //echo"<td>".$row['room_needed']."</td>";
      echo"<td><button type='submit' name='add' value='Add Room'><a href='/hotel/hotelupdate.php?id=$row[id] & rtype=$row[room_type]
        & avl=$row[available]'>ADD ROOM</a></button><td>";
      echo"</tr>";
       }

     }
echo"</table>";

echo"<a href='/hotel/adminlogout.php'>SHOW BOOK HISTORY</a>";

}
?>


