<?php
include"connection.php";
$id=$_REQUEST['id'];
$query="delete from moddy_moon_det where ID='$id'";
$data=mysqli_query($conn,$query);
if($data)
{
echo'<script> alert("recorde deleted sucessfully")</script>';
echo'<script>window.location.href="/hotel/admindashboard.php"</script>';
}
?>