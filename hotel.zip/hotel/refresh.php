<?php

include "connection.php";
$order=$_REQUEST['refresh'];
if(isset($_REQUEST['refresh']))
{
	$sql="update `booking_details` set room_needed=0";
	$res=mysqli_query($conn,$sql);
	if($res)
	{
		echo "<script>alert('now you can go for Booking')</script>";
		echo'<script>window.location.href="/hotel/roomfetch.php"</script>';
	}
}
?>