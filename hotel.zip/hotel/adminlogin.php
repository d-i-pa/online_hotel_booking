<?php
 error_reporting(0);
session_start();
if(!$_SESSION["login_user"]){
echo $_SESSION["unsucesfull"];
}
if($_SESSION["unsucesfull"]){
unset($_SESSION["unsucesfull"]);
}
?>
<html>
<head>
	<title>HELLO ADMIN LOGIN HERE</title>

<style>
body {
  font-family: Arial, Helvetica, sans-serif;
   background-image: linear-gradient( to right,red, yellow);
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color:rgba(0,0,0,0.6);
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #FFEFD5;
}/*text and passord filed*/

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color:#0000CC;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
<P><center><b><h1 style="color:rgba(0,0,0,0.7) ">DRP ONLINE HOTEL LOG IN PROTAL FOR ADMIN</h1></b></center></p>
</head>
<body>
<form action="/hotel/adminlogaction.php"  method="post" style="border:1px solid #ccc">
  <div class="container">
    <h1 style="color:#FF0099">LOG IN</h1>
    <p style="color:#FF0099">Please log in here.</p>
    <hr>

    <label for="Username" style="color:#FF0099"><b>USER NAME</b></label>
    <input type="text" placeholder="enter here your userid" name="user" id="user" required>
    <label for="password"style="color:#FF0099"><b>PASSWORD</b></label>
    <input type="password" placeholder="enter here your userid" name="pass" id="pass" 
    required>
    <label for="REMEMBER ME"style="color:#FF0099"><b>REMEMBER ME</b></label>
    <input type="checkbox" name="remember" id="remember" required>
    <button type="submit" name="login" value="LOG IN">LOG IN</button>
    </div>
  </div>
</form>
</body>
</html>