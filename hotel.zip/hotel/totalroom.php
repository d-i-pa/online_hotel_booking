<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<form method="post">
	<button type="submit" name="submit">SHOW TOTAL ROOM IN HOTEL MOODY MOON</button>
</form>
</body>
</html>
<?php
//session_start();
include"connection.php";
if(isset($_POST['submit']))
{
$sql1="select sum(`available`) as totalroom  from booking_details";
$res=mysqli_query($conn,$sql1);
if(mysqli_num_rows($res))
{
    echo"<table>";
    echo"<tr>";
    echo"<th>TOTAL ROOM IN MOODY MOON</th>";
    echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
    echo"<tr>";
    echo"<td>".$row['totalroom']."</td>";
    echo"</tr>";
    }
}
  echo"<table>";
}
?>