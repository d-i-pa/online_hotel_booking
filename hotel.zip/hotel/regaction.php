<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <title>Registration Action </title>
</head>
<body>

</body>
</html>
<?php
include "connection.php";
session_start();
error_reporting(0);
$name=$_REQUEST['name'];
$email=$_REQUEST['email'];
$mob=$_REQUEST['mob'];
$age=$_REQUEST['age'];
$city=$_REQUEST['city'];
$pin=$_REQUEST['pin'];
$gender=$_REQUEST['gender'];
$password=$_REQUEST['pass'];
$repass=$_REQUEST['repass'];
$target_path="image/";
$target_path = $target_path.basename($_FILES['filetoupload']['name']);
if(isset($_REQUEST['sbtn'])){
   if($password!==$repass)
   {
      $_SESSION['passnot']="Password Not Matched";
      header("location:/hotel/registration.php");
    }
    else
    {
      $sql1="select * from `user` where email_id='$email'";
      $checkres=mysqli_query($conn,$sql1);
      if(mysqli_num_rows($checkres))
      {
         echo'<script>alert("THIS EMAIL_ID or CONTACT_NUMBER ALREADY EXISTS")</script>';
         echo"windoiw.location.hreaf='/hotel/registraion.php/'</script>";
      }
      else{
         if(move_uploaded_file($_FILES['filetoupload']['tmp_name'],$target_path ))
         {
         $sql3="insert into `user`(id,name,email,contact,age,city,pin,gender,password,imgae) values('','$name','$email','$mob','$age','$city','$pin','$gender','$password','$target_path')";
             $result=mysqli_query($conn,$sql3);
             if($result)
             {
               echo"<script>alert('Your Registration Is Sucessfully Done')</script>";
               echo"<script>window.location.href='/hotel/login.php/'</script>";
             }
             echo "File uploaded successfully";
   
          }

             else
             {
               echo"<script>alert('Your Registration is canceled ')</script>";
                echo"<script>window.location.href='/hotel/registration.php/'</script>";
             }


             }

       }
    }

?>