<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Forget password </title>
	<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: #EE4949  ;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color: white;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #FFEFD5;
}/*text and passord filed*/

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #BDB76B;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>
	<div class="container">
   <form method="post">
	<h1>ENTER HERE YOUR ACCOUT DETALILS</h1>
    <p>PLEASE GIVE  US THE PROPER DETALISH TO CHANGE THE PASSWORD.</p>
    <hr>
    <label for="email"><b>EMAIL</b></label>
    <input type="text" placeholder="Enter Your Email_id " name="email" id="email" required>
     <hr>
      <button type="submit" class="registerbtn" name="submit">FIND ACCOUNT</button>
  </div>
</form>
</body>
</html>
<?php
session_start();
include "connection.php";
$searchnm=$_POST['email'];
if(isset($_POST['submit'])){
  $sql="select * from `user` where email='$searchnm'";
  $res=mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)){
    $_SESSION['searchname']=$searchnm;
    //echo $_SESSION['searchname'];
    echo'<script>window.location.href="/hotel/changepassword.php"</script>';
}
}
?>