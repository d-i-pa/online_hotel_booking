<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<!-- JavaScript Bundle with Popper -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
<link rel="stylesheet" href="/hotel/style.css">

<!-- Image and text -->
<nav class="navbar">
  <a class="navbar-brand" href="#">

    <img src="hotelpic/abc.png" width="50" height="50" class="d-inline-block align-top" alt="">
    Moody Moon
  </a>

  <a class="d-inline-block right">
    Already a Member
  </a>
  <a class="show" href="/hotel/login.php">log in</a>
</nav>
<P><center><b><h1 style="color:#283747">𝔻ℝℙ 𝕆ℕ𝕃𝕀ℕ𝔼 ℍ𝕆𝕋𝔼𝕃 ℝ𝔼𝔾𝕀𝕊𝕋ℝ𝔸𝕋𝕀𝕆ℕ 𝔽𝕆ℝ𝕄</h1></b></center></p>
<body style="background-image: url('hotelpic/footer.jpg');">

<div class="regform"><h1>Registration Form</h1></div>
<div class="main">
<form action="regaction.php" method="post" enctype="multipart/form-data">

    <h2 class="name">Name</h2>
    <input class="wholename" type="text" placeholder="Enter Name" name="name"    required>
  
    <h2 class="name">Email</h2>
    <input class="email"  type="email" placeholder="Enter Email" name="email"  required>
    <h2 class="name">Phone_number</h2>
    <input  class="phnumber" type="text" placeholder="Give a Mobile Number" name="mob"s required>
    <h2 class="name">Age</h2>
    <input  class="age" type="text" placeholder="enter your age" name="age" required>
    <h2 class="name">City</h2>
    <select class="option" name="city" id="city">
    <option value="Select City">--Select City--</option>
    <option value="Alipurduar">Alipurduar</option>
    <option value="Bankura">Bankura</option> 
    <option value="Birbhum">Birbhum</option>
    <option value="Cooch Behar">Cooch Behar</option>
    <option value="Dakshin Dinajpur">Dakshin Dinajpur</option>
    <option value="Cooch Behar">Cooch Behar</option>
    <option value="Darjeeling">Darjeeling</option>
    <option value="Hooghly">Hooghly</option>
    <option value="Howrah">Howrah</option>
   </select><br></br>
    <h2 class="name">Pin Code</h2>
    <input class="code" type="text" placeholder="Enter your city pin" name="pin" required>
  <h2 class="name">Gender</h2> 
  <label class="radio">  
  <input class="radio-one" type="radio" checked="checked" id="male" name="gender" value="male">
  <span class="checkmark"></span>
  Male
 </label>
 <label class="radio">
    <input class="radio-two" type="radio" id="female" name="gender" value="female">
   <span class="checkmark"></span>
   Female
 </label>
 <label class="radio">
  <input class="radio-three" type="radio" id="other" name="gender" value="other">
  <span class="checkmark"></span>
  Others
</label>
  <h2 class="name">PAssword</h2>
    <div id="name">
    <input  class="firstpass" type="password" placeholder="Enter Password" name="pass" required>
    <label class="firstlabel">Create password</label>
    <input class="lastpass" type="password" placeholder="Repeat Password" name="repass" required>
    <label style="transform: translate(-114px, -4px);" class="lastlabel">Confirm Password</label>
   </div>
      <?php
       error_reporting(0);
       session_start();
       echo  $_SESSION['passnot'];
       if($_SESSION['passnot']){
       unset($_SESSION['passnot']);
      }
      ?>
    <h2 class="name">Image Upload</h2>
    <div class="file-upload-wrapper" data-text="select your file">
    <input type="file" name="filetoupload" class="file-upload-field" id="actual-btn" value="">
    </div>
    <div>
    <button type="submit" class="registerbtn" name="sbtn">Register Here</button>
   </div>
   <div>
    <p style="color:white">Already have an account? 
       <a style="color:#33bbaa;" href="/hotel/login.php/">Sign in</a>
    </p>
   </div>
</div>
</form>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="hotel/main.js"></script>
</html>
