<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title> Moody Moon</title>
    <link rel="stylesheet" href="/hotel/style1.css"></link>
</head>
<body>
        <!--navbar-->
<div class="navbar">
  <div class="logo"><h1> MOODY</h1>
   </div>
   <div class="nav-menu">
   	<li><a id="col" href="/hotel/homepage.php">Home</a></li>
   	<li><a id="col" href="/hotel/registration.php">Register</a></li>
    <li><a  id="col" href="/hotel/adminlogin.php">Admin Login</a></li>
   	<li><a id="col" href="/hotel/login.php">Log In</a></li>
   	<li><a id="col" href="/hotel/aboutus.php">About Us</a></li>
   	<li><a  id="col" href="/hotel/contact.php">Contact</a></li>
   	</div>
   	</div>	
      <!-- main head-->
      <div class="main-head">
      <div class="banner-text">
      	<h1><span>MOODY MOON</span></h1>
      	<h2>Our<Span>&nbsp HOTEL</span> is best in the <Span>WEST BENGAL</span></h2>
      	<h3>we have<Span> 5Star</span> rating on<span>BOOK-HOTEL_ONLINE</span></h3>
      	</div>
      	<div class="btn">
      	<button id="room"><a id="col" href="/hotel/login.php">Book Room</a></button>
      </div>
    </div>
        <!--second head-->
        <div class="container">
        	<div class="box box1">
        		<h1>Our Service</h1>
        		<p>Guests of the Holiday Emerald are amazed at how genuinely kind their staff is. From thoughtful greetings upon entering the lobby to personally.</p>

        		<div class="btn1">
        			<button>Check</button>
        		</div>
        	</div>
        	<div class="box box2">
        		<h1> Hotel Room</h1>
        		  <p>A good hotel should have the most comfortable rooms and should be equipped with the necessary items. For instance, a room that has a.</p>
        		<div class="btn2">
        		  <button>Book</button>
        		</div>
        	</div>  
        	<div class="box box3">
        		<h1>Buffet</h1>
        		<p>Buffets are a style of serving meals in which food is placed in a public area where the guests can serve themselves. .</p>
        	  <div class="btn3">
        	     <Button>Meals</Button>
        	  </div>
        	</div> 
        </div>
                       <!--third head-->
          <div class="container-2">
              <div class="content">
                  <h1>Happy coustomar</h1>
                   <p>Taking feedback from guests about the quality of food, or ambience is also very important. Some customers might like the food but they find the ambience very loud or unpleasing. ... With guest feedback, hotels and restaurants can ensure that their quality is on par with the customer's expectations.<p>
                   </div>
                  </div> 

        	<!--Fourth Head-->
        	<div class="contact-box">
        	<h2>BOOK APPOINENTMENT(you have to Log in)</h2>
        	<div class="form">
        		<input type="test" placeholder="name">
        		<br>
        		<input type="text" placeholder="email">
        		<br>
        		<input type="text" placeholder="Subject">
        	    </br>
        	    <button>submit</button>
            </div>
        </div>
                  <!--footer-->

           <div class="footer">
           	<div class="div-1 div1">
           		<h3>Linkes</h3>
           		<li><a href="#">Hotel</a></li>
           		<li><a href="#">Motel</a></li>
           		<li><a href="#">Resturent</a></li>
           		<li><a href="#">Halls</a></li>
           	</div>
           	<div class="div-1 div3">
           		<h3>Service</h3>
           		<li><a href="">Swmming</a></li>
           		<li><a href="">Gym</a></li>
           		<li><a href="">Parking</a></li>
           		<li><a href="">Disco</a></li>
           	</div>
           	<div class="div-1 div4">
           		<h3> social linkes <h3>
           		  <a href="https://web.whatsapp.com/"><img src="hotelpic/wp.png" alt="wapp"></a>
           			<a href="https://www.instagram.com/tajhotels/?hl=en"><img src="hotelpic/instagram.png" alt="insta"></a>
           			<a href="https://www.facebook.com/TajHotels/"><img src="hotelpic/fb.png" alt="fb"></a>
           			<a href="https://www.youtube.com/channel/UCdkTfWTgtZ9Bnyg7c2O_Ehg"><img src="hotelpic/youtube.png" alt="youtube"></a>
           		</div>
           	</div>
    </body>
</html>