<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script>
        /*setTimeout(function(){
            window.location.href = 'https://www.w3schools.com/graphics/svg_intro.asp';
        }, 5000);*/
        /*let firstnumber=34;
        console.log(firstnumber);
        let isApproved=false;
        let scootyColor=null;*/
        let veichle={
            firstname:'scooty',//key
            firstnum:44//key
        };
        //veichle.firstname;
        //veichle['firstname']="RTO";
        //console.log( veichle.firstname);

        //veichle['firstname']="RTO";
       /* let selectperson=['buku' ,'piku'];
        selectperson[2]='500';
        console.log(selectperson);*/
        function irritataing(name ,lastname) {
            console.log('inncoming call' + name +'  '+ lastname);
           }
             irritataing('didi', 'amiami');
  </script>
</head>
<body>
   <!--<h1>Thank you<h1>--> 
</body>
</html>
