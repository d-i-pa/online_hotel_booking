 <!DOCTYPE html>
<html>
<head>
    <title>sign in</title>

</body>
</html>
<?php
session_start();
include "connection.php";
//error_reporting(0);
//include "conncetion.php";
$email=mysqli_real_escape_string($conn,$_REQUEST['email']);
$password= mysqli_real_escape_string($conn,$_REQUEST['pass']);
$remember=$_REQUEST['remember'];
//echo $user;
//echo $password;
if(isset($_POST['submit']))
{
    if(isset($_POST['remember']))
    {
        setcookie('email',$user,time()+60*60*7);
        setcookie('password',$password,time()+60*60*7);
        setcookie('remember',$remember,time()+60*60*7);
    }
    else
    {
        setcookie('email',$user,time()-60*60*7);
        setcookie('password',$password,time()-60*60*7);
        setcookie('remember',$remember,time()-60*60*70);  

    }
 $sql="select * from `user` where email='$email' and password='$password'";
    $result=mysqli_query($conn,$sql);
    $found_num_rows=mysqli_num_rows($result);
    if($found_num_rows)
    {
        $_SESSION["login_user"]=$email;
        echo $_SESSION["login_user"];
        header("location:/hotel/dashboard.php/");
        
    }
    else
    {

        $_SESSION["unsucesfull"]="invalid user detalis";
        header("location:/hotel/login.php/");
    }
}

?>