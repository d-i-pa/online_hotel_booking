<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<form method="post">
	<button type="submit" name="submit">SHOW TOTAL BOOKED ROOM IN MOODY MOON</button>
</form>
</body>
</html>
<?php
//session_start();
include"connection.php";
if(isset($_POST['submit']))
{
$sql1="select sum(`room_needed`) as booked  from moody_moon";
$res=mysqli_query($conn,$sql1);
if(mysqli_num_rows($res))
{
    echo"<table>";
    echo"<tr>";
    echo"<th>reserve_room in moody_moon</th>";
    echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
    echo"<tr>";
    echo"<td>".$row['booked']."</td>";
    echo"</tr>";
    }
}
  echo"<table>";
}
?>