<?php
  $conn=mysqli_connect("localhost","root","","hotel") or mysqli_connect_error();
?>