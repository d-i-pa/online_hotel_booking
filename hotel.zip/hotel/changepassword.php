<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Process For change password</title>
		<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color:#2E4053 ;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
  padding: 16px;
  background-color:#FF5722;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #F1C40F;
}/*text and passord filed*/

input[type=text]:focus, input[type=password]:focus {
  background-color: #58D68D;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color:#BDBDBD;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color:  #9CCC65;
  text-align: center;
}
</style>
</head>
<body>
<div class="container">
<form method="post">
<label for="password"><b>ENTER PASSWORD</b></label>
<input type="text" placeholder="Enter a new password" name="pass"><br></br>
<label for="Reenter Psw"><b>PLEASE RE_ENTER YOUR PASSWORD</b><label>
<input type="text" placeholder="Re-enter your  new password" name="pass1"><br></br>	
 <button type="submit" class="registerbtn" name="submit">Set Password</button>
</from>
<div>
</body>
</html>
<?php
session_start();
include"connection.php";
$useracnm=$_SESSION['accountuser'];
if(isset($_POST['submit'])){
	$password=$_POST['pass'];
    $conpass=$_POST['pass1'];
    if($password!==$conpass){
    	echo"<script>alert('BOth 2 are not same')</script>";
    	echo"<script>window.location.href='/hotel/forgetpass.php/'</script>";
      }
      else
      {
      	$sql="update `user` set password='$password' where email='$useracnm'";
        $result=mysqli_query($conn,$sql);
       if($result){
        echo'<script>alert("password changed")</script>';
        echo'<script>window.location.href="/hotel/logout.php/"</script>';
        }
       else
        {
         echo'<script>alert("something went wrong")</script>';
         echo'<script>window.location.href="/hotel/logout.php/"</script>';
        }

        	
        
      }
}

?>