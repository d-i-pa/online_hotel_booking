<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,300;0,400;0,700;1,300;1,400;1,700&display=swap" rel="stylesheet">
<!-- JavaScript Bundle with Popper -->
<style>
.backcolor{
   background-image: linear-gradient(to right,#808B96 ,#273746);
   /* position: absolute !important;
    top: 0;
    left: 0;
    z-index: 1*/
   }
   .navbar-brand, .right
   {
   	font-family:'Roboto Condensed', sans-serif;
   	font-weight: 400px;
   	font-style: italic;
   	font-size: 24px;
   	color: #fff;
   	transition: 0.3s;
   	text-decoration: none;
   }
   .navbar-brand:hover{
   	color: #fff;
   }
.right:hover{
	color: #F9E79F ;
	text-decoration: none;
}
.show{
	text-decoration: none;
	color: #1C2833;
	background: white;
	padding: 5px 10px ;
	border-radius:15px ;
}
.show1{
	text-decoration: none;
	color: #1C2833;
	background: white;
	padding: 5px 10px ;
	border-radius:15px ;
	transform: translate(269px, 0px);

}

</style>
</head>
<body>
<nav class="navbar backcolor" >
  <a class="navbar-brand" href="#">

    <img src="../hotelpic/abc.png" width="50" height="50" class="d-inline-block align-top" alt="">
    Moody Moon
  </a>

  <a class="d-inline-block right">
    Visit Our Side
  </a>
  <a class="show1" href="/hotel/modyform.php">Book Now</a>
  <a class="show" href="/hotel/logout.php">log out</a>
</nav>
<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="../hotelpic/1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>First slide label</h5>
        <p>Some representative placeholder content for the first slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="../hotelpic/kin3.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Second slide label</h5>
        <p>Some representative placeholder content for the second slide.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="../hotelpic/king.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Third slide label</h5>
        <p>Some representative placeholder content for the third slide.</p>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<a href="/hotel/modyform.php">book here</a>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>

</html>
<?php
error_reporting(0);
session_start();
if(!$_SESSION["login_user"])
{
	header("location:/hotel/login.php/");
}
echo"welcome";
echo"<a href='/hotel/modyform.php'>Book Here</a>";
echo"<a href='/hotel/logout.php/'>LOG OUT</a>";
?>

