-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 27, 2021 at 01:32 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel`
--

-- --------------------------------------------------------

--
-- Table structure for table `admintb`
--

CREATE TABLE `admintb` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admintb`
--

INSERT INTO `admintb` (`id`, `username`, `password`) VALUES
(1, 'piku2020@admin', 'piku2020'),
(2, 'buku4040@admin', 'buku4040'),
(3, 'polo1616@gmail.com', 'polo1616'),
(4, 'arpita2222@admin', 'arpita2222');

-- --------------------------------------------------------

--
-- Table structure for table `booking_details`
--

CREATE TABLE `booking_details` (
  `id` int(11) NOT NULL DEFAULT 0,
  `room_type` varchar(255) NOT NULL,
  `available` int(11) NOT NULL,
  `room_needed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking_details`
--

INSERT INTO `booking_details` (`id`, `room_type`, `available`, `room_needed`) VALUES
(0, 'Standard Room (1 to 2 People)                ', 19, 0),
(1, 'Family Room (1 to 4 People)           ', 7, 0),
(2, 'Privet Room(1 to 3 People)', 5, 0),
(3, 'Mix Dorm Room (6 People)', 4, 0),
(4, 'Female Dorm Room (6 people)', 2, 0),
(5, 'Male Dorm Room (6 people)', 0, 0),
(6, 'Standard Room (1 to 3People)', 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `moddy_moon_det`
--

CREATE TABLE `moddy_moon_det` (
  `id` int(11) NOT NULL,
  `room_type` varchar(255) NOT NULL,
  `available` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `moddy_moon_det`
--

INSERT INTO `moddy_moon_det` (`id`, `room_type`, `available`) VALUES
(1, 'Family Room (1 to 4 People)   ', 3),
(2, 'Privet Room(1 to 3 People)', 5),
(3, 'Mix Dorm Room (6 People)', 4),
(4, 'Female Dorm Room (6 people)', 3),
(5, 'Male Dorm Room (6 people)', 3);

-- --------------------------------------------------------

--
-- Table structure for table `moody_moon`
--

CREATE TABLE `moody_moon` (
  `room_number` int(11) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `free_pickup` varchar(255) NOT NULL,
  `flight_number` varchar(50) NOT NULL,
  `train_number` varchar(50) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_needed` int(11) NOT NULL,
  `no_of_guests` varchar(50) NOT NULL,
  `special_requests` varchar(355) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `moody_moon`
--

INSERT INTO `moody_moon` (`room_number`, `fname`, `lname`, `email`, `free_pickup`, `flight_number`, `train_number`, `room_type`, `room_needed`, `no_of_guests`, `special_requests`) VALUES
(1, 'Dipa', 'Pal', 'dipa.pal1998@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Family Room (1 to 4 People)', 1, '2', 'need a well decrated room'),
(2, 'Rupa', 'Pal', 'rupa.pal1996@gmail.com', 'No Thanks I will arrenge', 'N.A.', '37980993', 'Privet Room(1 to 3 People)', 2, '4', 'Plz Provide a need and clean room'),
(3, 'Partha ', 'Pal', 'parthapal1960@gmail.com', 'Yes!Pick Me Up On Arrival', '123569', 'N.A.', 'Mix Dorm Room (6People)', 2, '8', 'need good quality of food'),
(4, 'Saraswati', 'Pal', 'sarapal1771@gmail.com', 'No Thanks I will arrenge', 'N.A.', '4569875', 'Female Dorm Room(6)', 2, '12', 'good wash room required'),
(5, 'Dibyendu ', 'Banarjee', 'dibbunath1995@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', '123456', ' Male Dorm Room(6)', 1, '6', 'nothing'),
(6, 'Ananya ', 'Basu', 'ananyabasu2512@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'Nothing requried'),
(7, 'Piku ', 'Pal', 'pikupal4040@gmail.com', 'No Thanks I will arrenge', '33369800', 'N.A.', 'Family Room (1 to 4 People)', 1, '3', 'need only hygienic atmosphere'),
(8, 'Deba', 'De', 'deba2121@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(10, 'Shrestha', 'Choudhury', 'munna2121@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(11, 'Paro', 'De', 'parode1222@gmail.com', 'Yes!Pick Me Up On Arrival', '123569', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'NEED A PROPER CLEAN ROOM'),
(12, 'Bulu', 'Pal', 'buku2323@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Privet Room(1 to 3 People)', 1, '2', 'Nothing'),
(13, 'Arnab', 'Paul', 'ap1284@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Mix Dorm Room (6 People)', 1, '5', 'no'),
(14, 'Rima', 'Santra', 'rima1234@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'Nothing'),
(17, 'Deba', 'Roy', 'roy1997@user', 'Yes!Pick Me Up On Arrival', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(18, 'buchi', 'de', 'buchi2121@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Female Dorm Room (6 people)', 1, '6', 'nothing'),
(19, 'Dipayan', 'Bera', 'dip1234@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Mix Dorm Room (6 People)', 1, '5', 'nothing'),
(20, 'deb', 'Pal', 'deb123@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', '37980993', 'Mix Dorm Room (6 People)', 1, '5', 'nothing'),
(21, 'uff', 'De', 'uffyaa12@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 3, '4', 'nothing'),
(22, 'uff', 'De', 'uffyaa12@gmail.com', 'No Thanks I will arrenge', 'N.A.', 'N.A.', 'Standard Room (1 to 2 People)', 3, '4', 'nothing'),
(23, 'Buku', 'pal', 'buku2020@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', 'N.A.', 'Privet Room(1 to 3 People)', 1, '3', 'nothing'),
(24, 'kalpana', 'pal', 'kalpana@1234', 'Yes!Pick Me Up On Arrival', '33369800', '4569875', 'Mix Dorm Room (6 People)', 1, '5', 'nothing'),
(25, 'Dipa', 'Pal', 'dipa.pal1998@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', '123456', 'Family Room (1 to 4 People)', 4, '5', 'nothing'),
(26, 'rani', 'Pal', 'dipa.pal1998@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', '123456', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(27, 'rani', 'de', 'dipa.pal1998@gmail.com', 'Yes!Pick Me Up On Arrival', 'N.A.', '4569875', 'Standard Room (1 to 2 People)', 1, '2', 'no'),
(28, 'Deba', 'Pal', 'pri12@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(29, 'Deba', 'Pal', 'pri12@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing'),
(30, 'Deba', 'Pal', 'pri12@gmail.com', 'Yes!Pick Me Up On Arrival', '452698', 'N.A.', 'Standard Room (1 to 2 People)', 1, '2', 'nothing');

-- --------------------------------------------------------

--
-- Table structure for table `room_booking`
--

CREATE TABLE `room_booking` (
  `id` int(11) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_needed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `room_booking`
--

INSERT INTO `room_booking` (`id`, `room_type`, `room_needed`) VALUES
(1, 'Standard Room (1 to 2 People)', 0),
(2, 'Family Room (1 to 4 People)', 0),
(3, 'Privet Room(1 to 3 People)', 0),
(4, ' Mix Dorm Room (6People)', 0),
(5, 'Female Dorm Room(6) ', 0),
(6, 'Male Dorm Room(6) ', 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `age` int(3) NOT NULL,
  `city` varchar(50) NOT NULL,
  `pin` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(16) NOT NULL,
  `imgae` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `contact`, `age`, `city`, `pin`, `gender`, `password`, `imgae`) VALUES
(3, 'DIPA PAL', 'dipa.pal1998@gmail.com', '7890669381', 22, 'Hooghly', '712101', 'female', '120598', 'image/'),
(4, 'Rupa Pal', 'rupa.pal1996@gmail.com', '7003686883', 25, 'Howrah', '7000078', 'female', 'Rupa@96', 'image/'),
(5, 'Dipayan Bera', 'dipayan921@gmail.com', '9432552607', 26, 'Birbhum', '789623', 'male', 'dip@29', 'image/'),
(6, 'Shrestha Choudhary', 'shresthagmail.1698@gmail.com', '8981539092', 22, 'Birbhum', '6003122', 'female', 'munna1205', 'image/'),
(7, 'Partha Pal', 'parthapal1960@gmail.com', '9432954684', 61, 'Howrah', '7000078', 'male', 'partha2460', 'image/'),
(8, 'Saraswati Pal', 'sarapal1771@gmail.com', '9433666603', 52, 'Cooch Behar', '600312', 'female', '12345', 'image/'),
(9, 'Buchi', 'buchi2121@gmail.com', '9432954684', 26, 'Birbhum', '600312', 'female', '1555', 'image/'),
(10, 'Dipayan Bera', 'dip1234@gmail.com', '7003686883', 52, 'Alipurduar', '7000078', 'male', '1235', 'image/'),
(11, 'Sarama Pal', 'sara2345@gmail.com', '7890669381', 25, 'Howrah', '7000078', 'female', 'sara@1234', 'image/'),
(12, 'Subha das', 'subha12@gmail.com', '9432954684', 26, 'Hooghly', '712101', 'male', '1243', 'image/beb9f850d3ec3a9e86d6c22f36705c90.jpg'),
(13, 'Munna Ray', 'munna3434@gmail.com', '9432552607', 22, 'Howrah', '6003122', 'male', '12345', 'image/d327fb8d28ed207dab95937b2016ef73.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admintb`
--
ALTER TABLE `admintb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_details`
--
ALTER TABLE `booking_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moddy_moon_det`
--
ALTER TABLE `moddy_moon_det`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `moody_moon`
--
ALTER TABLE `moody_moon`
  ADD PRIMARY KEY (`room_number`);

--
-- Indexes for table `room_booking`
--
ALTER TABLE `room_booking`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admintb`
--
ALTER TABLE `admintb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `moddy_moon_det`
--
ALTER TABLE `moddy_moon_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `moody_moon`
--
ALTER TABLE `moody_moon`
  MODIFY `room_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `room_booking`
--
ALTER TABLE `room_booking`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
