<?php
 error_reporting(0);
session_start();
if(!$_SESSION["login_user"]){
echo $_SESSION["unsucesfull"];
}
if($_SESSION["unsucesfull"]){
unset($_SESSION["unsucesfull"]);
}
?>
<html>
<head>
	<title>LOG IN HERE</title>
  <style>
  body{
    margin: 0px;
    padding: 0px;
    background: url("hotelpic/ss.jpg");
    background-size: cover;
    background-position: center;
    font-family: sans-serif;
    padding: 10px 30px;
  }
  .loginbox{
    width: 320px;
    height: 420px;
    background-color:rgb(0,0,0,0.7);
    color: #fff;
    top: 50%;
    left: 50%;
    position: absolute;
    transform: translate(-50%,-50%);
    box-sizing: border-box;
    padding: 70px 30px;
  }
  .avatar{
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    top: -50px;
    left: calc(50% - 50px);
  }
  h1
  {
    margin: 0;
    padding: 0 0 20px;
    text-align: center;
    font-size: 22px
  }
  .loginbox p{
    margin: 0;
    padding: 0;
    font-weight: bold;
  }
  .loginbox input{
    width: 100%;
    margin-bottom: :20px;
  }
  .loginbox input[type="text"],input[type="password"]
  {
    border:none;
    border-bottom: 1px solid #fff;
    background: transparent;
    outline: none;
    height: 40px;
    color: #fff;
    font-size: 16px;
  }
  .loginbox input[type="submit"]
  {
    border: none;
    outline: none;
    height: 40px;
    background: #fb2525;
    color: #fff;
    font-size: 18px;
    border-radius: 20px;
  }
  .loginbox input[type="submit"]:hover
  {
    cursor: pointer;
    background: #ffc107;
    color: #000;
  }
.loginbox a{
  text-decoration: none;
  font-size: 12px;
  line-height: 20px;
  color: darkgray;

}
.rem{
  transform: translate(0px, -19px);
}
</style>
<P><center><b><h1 style="color:#212F3D ">𝔻ℝℙ 𝕆ℕ𝕃𝕀ℕ𝔼 ℍ𝕆𝕋𝔼𝕃 𝕃𝕆𝔾 𝕀ℕ ℙℝ𝕆𝕋𝔸𝕃</h1></b></center></p>
</head>
<body>
  <div class="loginbox">
    <image src="hotelpic/img.png" class="avatar">
    <h1>LOG IN HERE</h1>
    <form action="/hotel/logaction.php"  method="post">
    <p>USER NAME</p>
     <input type="text"  value="<?php if(isset($_COOKIE['email'])){echo $_COOKIE['email'];}?>"name="email" required>
     <p>Password</p>
    <input type="password"  value="<?php if(isset($_COOKIE['password'])){echo $_COOKIE['password'];}?>" name="pass" required></br>
    
    <p>REMEMBER ME:</p>
    <input type="checkbox" name="remember" class="rem"  value="<?php if(isset($_COOKIE['remember'])){ ?> checked <?php } ?>"></br>
    
    <input type="submit"  name="submit" value="LOG_IN"><br></br>
    <a href="/hotel/forgetpass.php/">FORGET PASSWORD</a><br></br>
    <a href="/hotel/registration.php/">Register Here</a><br><br>
</form>
</div>
</body>
</html>