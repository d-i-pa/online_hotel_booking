<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<p>hello</p>
<a href="/hotel/modyform.php">
<img src="hotelpic/1.jpg" alt="Italian Trulli">
</a>
</body>
</html>
