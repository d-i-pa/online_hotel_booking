<html>
<head>
	<meta charset="utf-8">
	<title>show booking detalish</title>
	<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
	width: 100%px;
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<form method="post">
<button type="submit" name="book" value="click TO BOOK">CLICK FOR BOOKING PROCESS</button>
</form>
</body>
</html>



<?php
/*include"connection.php";
error_reporting(0);
//$email=$_POST['email'];
if(isset($_POST['book']))
{
$sql="SELECT id,room_type,(`available`-`room_needed`) as remaining_room from booking_details;";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
  echo"<table>";
  echo"<tr>";
  echo"<th>ROOM ID.</th>";
  echo"<th>ROOM TYPE.</th>";
  echo"<th>REMAINING ROOM</th>";
  //echo"<th>ROOM_NEEDED</th>";
  echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
      echo"</tr>";
      echo"<td>".$row['id']."</td>";
      echo"<td>".$row['room_type']."</td>";
      echo"<td>".$row['remaining_room']."</td>";
      //echo"<td>".$row['room_needed']."</td>";
      echo"</tr>";
       }

     }
echo"</table>";
}*/
?>
<?php
include"connection.php";
error_reporting(0);
//$email=$_POST['email'];
if(isset($_POST['book']))
{
$sql="select * from booking_details";
$res=mysqli_query($conn,$sql);
if(mysqli_num_rows($res)>0)
{
	echo"<table>";
	echo"<tr>";
	echo"<th>ROOM ID.</th>";
	echo"<th>ROOM TYPE.</th>";
	echo"<th>ROOM AVAILABLE</th>";
	echo"<th>ROOM NEEDED.</th>";
  echo"</tr>";
    while($row=mysqli_fetch_assoc($res))
    {
    	echo"</tr>";
    	echo"<td>".$row['id']."</td>";
    	echo"<td>".$row['room_type']."</td>";
    	echo"<td>".$row['available']."</td>";
    	echo"<td>".$row['room_needed']."</td>";
    	echo"<td><button type='submit' name='book' value='book'><a href='/hotel/roombook.php?id=$row[id] & rtype=$row[room_type] & avl=$row[available]
    	  & need=$row[room_needed]'>BOOK</a></button><td>";
    	echo"</tr>";
    	 }

     }
echo"</table>";

       echo"<a href='/hotel/checkout.php'>Check Out whole Booking Detailsh</a>";
       

}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title></title>
</head>
<body>
<form method="post" action="/hotel/refresh.php">
<center><input type="submit" name="refresh" value="REFRESH PAGE"></center>
</form>
</body>
</html>